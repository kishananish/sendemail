const fs = require('fs');
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');

var mailAccountUser = 'info@rexsoftech.com'
var mailAccountPassword = 'Rexsoftech@123123'

var fromEmailAddress = 'info@rexsoftech.com'
var toEmailAddress = 'info@rexsoftech.com'

var transport = nodemailer.createTransport(smtpTransport({
    // service: 'gmail',
    // auth: {
    //     user: mailAccountUser,
    //     pass: mailAccountPassword
    // }

    host: 'cp-rsl01.sin02.ds.network',
    port: 995,
    auth: {
        user: mailAccountUser,
        pass: mailAccountPassword
    }
    
    
    ,
    tls: {
        rejectUnauthorized: false
    }
}))





fs.readFile('./templates/forgotpassword.html', 'utf8', function (err, content) {
if (err) {
  console.log('sendEmail err', err);
}
content = content.replace('$user_name$', 'KishanKumar');
content = content.replace('#urlisqeni#', 'KishUrl');
content = content.replace('$user_code$', '3456');


var mail = {
    from: fromEmailAddress,
    to: toEmailAddress,
    subject: "hello world!",
    text: content,
    html: content
}

transport.sendMail(mail, function(error, response){
    if(error){
        console.log(error);
    }else{
        console.log("Message sent: " + content);
    }

    transport.close();
});

});